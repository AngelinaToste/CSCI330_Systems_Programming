//Angelina Toste
#include "./hw6-free.h"
#include "./hw6-main.h"
#include "./hw6-scan.h"
#include "./hw6-load.h"
#include "./hw6-search.h"

void FREE(struct _data *Blackbox, int size)
{ // frees up all dynamic memory that was allocated. recall how many times calloc or malloc have been called.
 //need to free() multiple times for all of the "name" pointers in the struct (use size)
 // also need to free Blackbox

	for (int i = 0; i < size; i++)
	{
		free(Blackbox[i].name);
	}
	free(Blackbox);

}
