//Angelina Toste

#ifndef HW6_LOAD_H_
#define HW6_LOAD_H_
#endif /* HW6_LOAD_H_ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct _data *LOAD(FILE*, int );
