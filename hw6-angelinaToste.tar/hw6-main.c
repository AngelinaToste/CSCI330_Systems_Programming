//Angelina Toste
#include "./hw6-main.h"
#include "./hw6-scan.h"
#include "./hw6-load.h"
#include "./hw6-search.h"
#include "./hw6-free.h"

int main (int argv,char **argc)
{

    FILE* data;

    // determine how many lines in the file
    int size = SCAN (&data);

    //populate the dynamic struct array, Blackbox
    struct _data *Blackbox;
    Blackbox= (LOAD(data, size));

    // handles case when no command line argument is provided
    if (argv < 2)
    {
        printf("\n*******************************************\n* You must include a name to search for.  *\n*******************************************\n");
        exit(1);
    }
    else
    {
    	// handles case when a command line argument is provided, searches for argument in the struct array
    	SEARCH(Blackbox, argc[1], size);

    }

    FREE(Blackbox, size);


    return 0;

}

