//Angelina Toste

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef HW6_MAIN_H_
#define HW6_MAIN_H_

#endif /* HW6_MAIN_H_ */


#ifndef _JUNK_
#define _JUNK_
struct _data {
	char *name;
	long number;
};
#endif



int main (int, char**);
