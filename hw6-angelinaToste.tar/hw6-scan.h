// Angelin Toste

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef HW6_SCAN_H_
#define HW6_SCAN_H_
#endif /* HW6_SCAN_H_ */


#ifndef _JUNK_
#define _JUNK_
struct _data {
	char *name;
	long number;
}junk;
#endif

int SCAN(FILE*(*));
