// Angelina Toste
#include "./hw6-search.h"
#include "./hw6-main.h"
#include "./hw6-scan.h"
#include "./hw6-load.h"
#include "./hw6-free.h"

void SEARCH(struct _data *Blackbox, char *name, int size)
{//gets dynamic array of struct that was passed to it, name being searched for, size of array
 //searches for name in list

 int counter = 0;
 while( counter < size)
 {
     if( strcmp(Blackbox[counter].name, name) == 0 ) // if the name matches a name in the list
     {
    	 printf("\n*******************************************\n The name was found at the %i entry.  \n*******************************************\n", counter);
        return;
     }
    counter++;
 }

 // if NO matches found in the list
 printf("\n*******************************************\n The name was NOT found.  \n*******************************************\n");

}
