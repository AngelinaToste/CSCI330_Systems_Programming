//Angelina Toste
#include "hw7-main.h"
// this is a modified main file for hw6 to accomodate the use of dlopen, dlsym, etc

int main (int argv,char **argc)
{
	// making handle pointer and function pointers
	void *handle;
	int (*SCAN)(FILE*(*));
	struct _data *(*LOAD)(FILE*, int );
	void (*SEARCH)(struct _data*, char*, int);
	void (*FREE)(struct _data *Blackbox, int);

	handle = dlopen("./hw7-lib-angelinaToste.so", RTLD_LAZY);
	if (!handle) printf("%s\n", dlerror());
	SCAN = dlsym(handle, "SCAN");
	LOAD = dlsym(handle, "LOAD");
	SEARCH = dlsym(handle, "SEARCH");
	FREE = dlsym(handle, "FREE");

    FILE* data;

    // determine how many lines in the file
    int size = (*SCAN) (&data);

    //populate the dynamic struct array, Blackbox
    struct _data *Blackbox;
    Blackbox= (*LOAD)(data, size);

    // handles case when no command line argument is provided
    if (argv < 2)
    {
        printf("\n*******************************************\n* You must include a name to search for.  *\n*******************************************\n");
        exit(1);
    }
    else
    {
    	// handles case when a command line argument is provided, searches for argument in the struct array
    	(*SEARCH)(Blackbox, argc[1], size);

    }

    (*FREE)(Blackbox, size);
    dlclose(handle);

    return 0;

}

