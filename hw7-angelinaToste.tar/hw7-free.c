//Angelina Toste
#include "./hw7-main.h"
#include "./hw7-scan.h"
#include "./hw7-load.h"
#include "./hw7-search.h"
#include "hw7-free.h"

void FREE(struct _data *Blackbox, int size)
{ // frees up all dynamic memory that was allocated. recall how many times calloc or malloc have been called.
 //need to free() multiple times for all of the "name" pointers in the struct (use size)
 // also need to free Blackbox

	for (int i = 0; i < size; i++)
	{
		free(Blackbox[i].name);
	}
	free(Blackbox);

}
