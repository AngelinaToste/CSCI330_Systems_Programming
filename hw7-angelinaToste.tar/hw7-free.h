//Angelina Toste

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef HW7_FREE_H_
#define HW7_FREE_H_
#endif/* HW7_FREE_H_ */

#ifndef _JUNK_
#define _JUNK_
struct _data {
	char *name;
	long number;
};
#endif

void FREE(struct _data *Blackbox, int);
