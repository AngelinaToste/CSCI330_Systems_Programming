//Angelina Toste

#include "hw7-load.h"

#include "hw7-free.h"
#include "hw7-main.h"
#include "hw7-scan.h"
#include "hw7-search.h"

struct _data *LOAD(FILE *stream, int size)
{ //rewind file, create dynamic array (of size), read data, populate struct dynamic array

	// open file for reading, rewind stream
    stream = fopen("hw4.data", "r");
    rewind(stream);


    //create dynamic array of size
    struct _data *Blackbox;
    Blackbox = calloc(size, sizeof(struct _data));

    //parameters for getline and strtok
    char *lineBuf= NULL;
    size_t lineBufSize = 0;
    int lineCount = 0;
    ssize_t lineSize;

    char *token;
    char *search = " ";


    int counter = 0;

    // get the size of the first line
    lineSize = getline(&lineBuf, &lineBufSize, stream);

    while (lineSize >= 0 && counter < size)
    {
    	// read each line, break it up, assign to variables in struct, increment counters

    	lineCount++;

    	// break up the line on the " " character
    	token  = strtok(lineBuf, search);

    	Blackbox[counter].name = malloc(strlen(token));
    	strcpy(Blackbox[counter].name, token);

        // get the second half of the line ending at the "\n" character
    	token  = strtok(NULL, "\n");
    	Blackbox[counter].number = atol(token);

    	// get next line and increment counter
    	lineSize = getline(&lineBuf, &lineBufSize, stream);
    	counter++;

    }

    //free and close lineBug and the file opened during the function
    free(lineBuf);
    lineBuf = NULL;
    fclose(stream);

    return Blackbox;

}


