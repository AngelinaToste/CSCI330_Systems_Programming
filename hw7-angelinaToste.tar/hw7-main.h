//Angelina Toste

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>

#ifndef HW7_MAIN_H_
#define HW7_MAIN_H_

#endif /* HW7_MAIN_H_ */


#ifndef _JUNK_
#define _JUNK_
struct _data {
	char *name;
	long number;
};
#endif

#include "hw7-free.h"
#include "hw7-load.h"
#include "hw7-scan.h"
#include "hw7-search.h"


int main (int, char**);
