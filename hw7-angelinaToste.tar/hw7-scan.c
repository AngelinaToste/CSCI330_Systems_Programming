// Angelina Toste
#include "hw7-scan.h"

#include "hw7-free.h"
#include "hw7-load.h"
#include "hw7-main.h"
#include "hw7-search.h"

int SCAN(FILE *(*stream))
{// open file/ stream, return integer indicating how many lines are in the file

	// open file for reading
	*stream = fopen("hw4.data", "r");

	// initializing counter for the number of lines in the file
	int numOfContacts = 0;

	if (*stream == NULL)
	{
		printf("error: file not found");
	}
	else
	{
		char* line = NULL;
		size_t size = 0;
		size_t nread;

        while ( (nread = getline(&line, &size, *stream)) != -1) // count the number of lines in the file
        {

        	numOfContacts++;
        }
        free(line);

	}

	//close the file
	fclose(*stream);

	//returns an integer indicating how many lines are in the file
	return numOfContacts;
}

