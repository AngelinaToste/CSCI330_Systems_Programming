// Angelin Toste

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef HW7_SCAN_H_
#define HW7_SCAN_H_
#endif /* HW7_SCAN_H_ */


#ifndef _JUNK_
#define _JUNK_
struct _data {
	char *name;
	long number;
}junk;
#endif

int SCAN(FILE*(*));
